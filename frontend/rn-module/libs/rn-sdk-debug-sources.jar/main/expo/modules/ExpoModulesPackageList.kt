package expo.modules;

import expo.modules.core.interfaces.Package;
import expo.modules.kotlin.modules.Module;
import expo.modules.kotlin.ModulesProvider;

class ExpoModulesPackageList : ModulesProvider {
  companion object {
    val packagesList: List<Package> = listOf(
          expo.modules.logbox.ExpoLogBoxPackage(),
      expo.modules.adapters.react.ReactAdapterPackage(),
      expo.modules.core.BasePackage(),
      expo.modules.kotlin.edgeToEdge.EdgeToEdgePackage()
    )

    val modulesMap: Map<Class<out Module>, String?> = mapOf(
          expo.modules.webview.DomWebViewModule::class.java to null,
      expo.modules.fetch.ExpoFetchModule::class.java to null,
      expo.modules.asset.AssetModule::class.java to null,
      expo.modules.clipboard.ClipboardModule::class.java to null,
      expo.modules.constants.ConstantsModule::class.java to null,
      expo.modules.filesystem.FileSystemModule::class.java to null,
      expo.modules.filesystem.legacy.FileSystemLegacyModule::class.java to null,
      expo.modules.font.FontLoaderModule::class.java to null,
      expo.modules.font.FontUtilsModule::class.java to null,
      expo.modules.keepawake.KeepAwakeModule::class.java to null 
    )

    @JvmStatic
    fun getPackageList(): List<Package> {
      return packagesList
    }
  }

  override fun getModulesMap(): Map<Class<out Module>, String?> {
    return modulesMap
  }
  
  override fun getServices(): List<Class<out expo.modules.kotlin.services.Service>> {
    return listOf<Class<out expo.modules.kotlin.services.Service>>(
          expo.modules.constants.ConstantsService::class.java
    )
  }
}
